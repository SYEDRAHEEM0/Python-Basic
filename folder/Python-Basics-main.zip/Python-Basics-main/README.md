# Python-Basics

<p> You will find the Jupyter noteooks on basics of python in this repo.</p>
